import 'package:ble_client/page/hasil_pengecekan/hasil_pengecekan_screen.dart';
import 'package:ble_client/page/home/home_screen.dart';
import 'package:flutter/material.dart';
import 'package:get/route_manager.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return GetMaterialApp(
      title: 'Flutter BLE Client',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.deepPurple),
        useMaterial3: false,
      ),
      getPages: [
        GetPage(name: HomeScreen.routeName, page: () => const HomeScreen()),
        GetPage(
            name: HasilPengecekanScreen.routeName,
            page: () => const HasilPengecekanScreen()),
      ],
    );
  }
}
