import 'package:flutter/material.dart';

const kLightBlueColor = Color(0xffD2EAFA);
const kLightRedColor = Color(0xffFAD2D2);
const kBlueColor = Color(0xff425DA1);
const kRedColor = Color(0xffC62F2F);
const kTextColor = Color(0xff0D0C22);
