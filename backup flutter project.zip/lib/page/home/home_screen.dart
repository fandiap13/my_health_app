import 'package:ble_client/controller/BluetoothController.dart';
import 'package:ble_client/enums.dart';
import 'package:ble_client/page/home/components/connected_device_component.dart';
import 'package:ble_client/page/home/components/connecting_device_component.dart';
import 'package:ble_client/page/home/components/disconnected_device_component.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});
  static String routeName = "/";

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final bluetoothC = Get.put(BluetoothController());

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: () async {
        // jika sedang tidak menyambungkan ke perangkat esp maka fungsi ini akan berjalan
        if (bluetoothC.status.value != Status.LOADING) {
          showDialog(
              context: context,
              builder: (context) {
                return AlertDialog(
                  title: const Text("Keluar"),
                  content:
                      const Text("Apakah anda ingin keluar dari aplikasi ?"),
                  actions: <Widget>[
                    TextButton(
                      onPressed: () {
                        SystemNavigator.pop();
                      },
                      child: const Text("Ya"),
                    ),
                    TextButton(
                      onPressed: () {
                        Navigator.of(context).pop(); // Close alert dialog
                      },
                      child: const Text("tidak"),
                    ),
                  ],
                );
              });
        }
        return false;
      },
      child: SafeArea(
        child: Scaffold(
          body: Obx(() {
            if (bluetoothC.status.value == Status.LOADING) {
              return const ConnectingDeviceComponent();
            } else if (bluetoothC.checkConnectionDevice()) {
              return const ConnectedDeviceComponent();
            } else {
              return const DisconnectedDeviceComponent();
            }
          }),
        ),
      ),
    );
  }
}
